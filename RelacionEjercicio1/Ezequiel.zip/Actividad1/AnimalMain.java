package Actividad1;

public class AnimalMain {

	public static void main(String[] args) {
		// Creamos el objeto
		animal elPerro = new perro("Lucas");
		
		//Llamamos al metodo
		elPerro.HacerSonido();
		
	}

}
