package Actividad5;

public class Figura {

	// Metodo para calcular area
	public double calcularArea() {
		return 0;
	}
}
