package Actividad6;

public class Empleado {
	//Atributos
	String nombre;
	
	//Creamos el contructor
	public Empleado (String nombre) {
		this.nombre=nombre;
	}
	
	//Creamos el metodo de mostrarDetalles
	public void mostrarDetalles() {
		System.out.println("Mostrar detalles");
	}
}
