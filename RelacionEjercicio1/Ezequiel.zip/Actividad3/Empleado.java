package Actividad3;

public class Empleado {
	
	//Atributos
	String nombre;
	
	//Contructor
	public Empleado (String nombre) {
		this.nombre=nombre;
	}
	
	//Metodo trabajar
	public void trabajar () {
		System.out.println("El empleado deberia trabajar");
	}
}
