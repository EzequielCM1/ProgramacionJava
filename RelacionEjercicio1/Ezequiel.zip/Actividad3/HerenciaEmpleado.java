package Actividad3;

public class HerenciaEmpleado {

	public static void main(String[] args) {
		
		//Creamos el objeto
		Gerente elgerente= new Gerente("Ezequiel");
		
		//Llamamos y mostramos en pantalla
		elgerente.trabajar();
	}

}
